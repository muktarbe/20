import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        try {
            Parallelepiped parallelepiped = new Parallelepiped(10, 5, 8);
            System.out.println("Parallelepiped Surface Area: " + parallelepiped.calculateSurfaceArea());
            System.out.println("Parallelepiped Volume: " + parallelepiped.calculateVolume());

            Cylinder cylinder = new Cylinder(4, 7);
            System.out.println("Cylinder Surface Area: " + cylinder.calculateSurfaceArea());
            System.out.println("Cylinder Volume: " + cylinder.calculateVolume());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}