public interface aa {
    public void area ();
    public void volume ();
}
