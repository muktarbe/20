class Parallelepiped {
    private double length;
    private double width;
    private double height;

    public Parallelepiped(double length, double width, double height) {
        if (length <= 0 || width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Invalid dimensions for Parallelepiped");
        }
        this.length = length;
        this.width = width;
        this.height = height;
    }

    public double calculateSurfaceArea() {
        return 2 * ((height * length) + (length * width) + (height * width));
    }

    public double calculateVolume() {
        return length * width * height;
    }
}
