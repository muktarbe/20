class Cylinder {

    private static final double PI = 3.14159;
    private double radius;
    private double height;

    public Cylinder(double radius, double height) {
        if (radius <= 0 || height <= 0) {
            throw new IllegalArgumentException("Invalid dimensions for Cylinder");
        }
        this.radius = radius;
        this.height = height;
    }

    public double calculateSurfaceArea() {
        return 2 * PI * radius * (height + radius);
    }

    public double calculateVolume() {
        return PI * radius * radius * height;
    }
}
